<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$location = $_POST['location'];
	$items = file_get_contents("stops.json");
	$obj = json_decode($items,true);

	$times = file_get_contents("stop_times.json");
	$times_j = json_decode($times,true);

	//print_r($x);

	 $result = $obj["stops"][$location]["stop_name"];
		// $array_keys = array_keys($response);




// echo "Stop ID: ".$obj['stops'][$i]["stop_id"]."<br>";
    		  		// echo "Stop Code: ".$obj['stops'][$i]["stop_code"]."<br>";
    		  		// echo "StopName"."<br>".$obj['stops'][$i]["stop_name"]."<br>";
    		  		// echo "Stop_lat"."<br>".$obj['stops'][$i]["stop_lat"]."<br>";
    		  		// echo "Stop_lon"."<br>".$obj['stops'][$i]["stop_lon"]."<br>";
    		  		// echo "WHeel"."<br>".$obj['stops'][$i]["wheelchair_boarding"]."<br>";
	 
		   for($i=0; $i<count($obj['stops']); $i++) {
		   
		   	// echo "for";÷
    		 	// $y = $obj['stops'][$i]["stop_id"]."<br>";
    		  // 	$x = $obj['stops'][$i]["stop_name"]."<br>";
    		  
    		  	if ($obj['stops'][$i]["stop_name"] == $location) {
    		  		 $a = $obj['stops'][$i]["stop_id"];
    		  			
    		  		// echo $q = count($times_j['stop_times']);
	  				for($j=0; $j<count($times_j['stop_times']); $j++) {

	 					if($times_j['stop_times'][$j]["stop_id"] == $obj['stops'][$i]["stop_id"]) {
	 						//echo "Stop Code: ".$obj['stops'][$i]["stop_code"]."<br>";
		    		  		echo "<br>"."StopName".$obj['stops'][$i]["stop_name"]."<br>";
		    		  		echo "Stop_lat".$obj['stops'][$i]["stop_lat"]."<br>";
		    		  		echo "Stop_lon".$obj['stops'][$i]["stop_lon"]."<br>";
		    		  		// echo "WHeel:".$obj['stops'][$i]["wheelchair_boarding"]."<br>";
 						     echo $e = $times_j['stop_times'][$j]["stop_id"]."<br>";	
	 						echo "Arrival Time".$e = $times_j['stop_times'][$j]["arrival_time"]."<br>";	
	 						echo "Departure Time".$e = $times_j['stop_times'][$j]["departure_time"]."<br>";
	 						echo "------------------------";	
 						}
    		  		}
    		  	
    		
				}
			}

}
	   
		
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form method="POST">
		<input type="text" name="location">
		<button type="submit">Sumit</button>
	</form>
</body>
</html>