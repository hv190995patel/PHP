<?php

	
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$location = $_POST['location'];
		 echo $items = file_get_contents("http://maps.google.com/maps/api/geocode/json?address=".$location);
		 $response = json_decode($items);
		echo "<br>"."Location: ".$location;
		echo "<br>"."Latitude Is:".$lat = $response->results[0]->geometry->location->lat;
		echo ".<br>"."Longitude Is:".$long = $response->results[0]->geometry->location->lng; 
		
	}
	
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form method="POST">
		<input type="text" name="location">
		<button type="submit">Sumit</button>
	</form>
</body>
</html>